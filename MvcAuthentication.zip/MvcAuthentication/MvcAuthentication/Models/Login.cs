﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcAuthentication.Models
{
    public class Login
    {
        [Required(ErrorMessage="Username required.",AllowEmptyStrings=false)]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password required.", AllowEmptyStrings = false)]
        [DataType( System.ComponentModel.DataAnnotations.DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "First Name", AllowEmptyStrings = false)]
        [DataType(System.ComponentModel.DataAnnotations.DataType.EmailAddress)]
        public string FirstName { get; set; }

        public string LastName { get; set; }


        [Required(ErrorMessage = "Date of Birth Required required.", AllowEmptyStrings = false)]
        [DataType(System.ComponentModel.DataAnnotations.DataType.Date)]
        public DateTime DateofBirth { get; set; }

        
        public bool RememberMe { get; set; }
    }
}