﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcAuthentication.Controllers
{
    public class HomeController : Controller
    {
        [AllowAnonymous] //This is for Un-Authorize User
        public ActionResult Index()
        {
            return View();
        }

        [Authorize] // This is for Authorize user
        public ActionResult MyProfile()
        {
            return View();
        }


    }
}
